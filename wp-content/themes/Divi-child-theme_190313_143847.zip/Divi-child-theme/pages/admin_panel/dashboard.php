<?php

?>

    <div id="device" class="device" style="width: 1100px; height: 1500px; transform: scale(1, 1); transform-origin: center top 0px;">
        <div class="stage-container animation-stage-container main-stage-container" style="left: 0px; top: 0px; width: 1100px; height: 1500px;">
            <ul class="stage">
                <li class="page-list-item" style="z-index: 1;">
                    <div class="page" id="594F130A-8D4D-4168-A113-303AC886D367" style="background-color: rgb(255, 255, 255);">
                        <div class="page-middle" style="width: 100%; height: 100%; overflow: auto; top: 0px;">
                            <div class="scroll-view">
                                <div class="scroll-content" style="overflow: auto;">
                                    <div class="page-container" style="margin-top: 0px; height: 6000px; width: 1100px;">
                                        <div class="components">
                                            <div style="z-index: 0;">
                                                <div id="5eb5cef2-b70a-c985-c1b6-7de3055f697f" class="component component-Tab" style="left: 26px; top: 20px; width: 1054px; height: 1462px; padding: 0px; opacity: 1; z-index: 0; transform: scaleX(1) scaleY(1);">
                                                    <div class="component-HorizontalTabBar">
                                                        <div class="bar-ex" style="height: 24px; margin-left: 12px; justify-content: flex-start;">
                                                            <div class="bar-item" style="line-height: 24px; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); border-width: 1px; border-style: solid; border-color: rgb(102, 102, 102) rgb(102, 102, 102) rgb(255, 255, 255); border-top-left-radius: 0px; border-top-right-radius: 0px; width: 205px; background-color: rgb(255, 255, 255);">
                                                                <label class="bar-item-text">Dashboard</label>
                                                            </div>
                                                            <div class="bar-item" style="line-height: 24px; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); border: 1px solid rgb(102, 102, 102); border-top-left-radius: 0px; border-top-right-radius: 0px; width: 205px; background-color: rgb(221, 221, 221);">
                                                                <label class="bar-item-text"> Profile</label>
                                                            </div>
                                                            <div class="bar-item" style="line-height: 24px; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); border: 1px solid rgb(102, 102, 102); border-top-left-radius: 0px; border-top-right-radius: 0px; width: 205px; background-color: rgb(221, 221, 221);">
                                                                <label class="bar-item-text"> User Interactions</label>
                                                            </div>
                                                            <div class="bar-item" style="line-height: 24px; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); border: 1px solid rgb(102, 102, 102); border-top-left-radius: 0px; border-top-right-radius: 0px; width: 205px; background-color: rgb(221, 221, 221);">
                                                                <label class="bar-item-text"> Reporting</label>
                                                            </div>
                                                            <div class="bar-item" style="line-height: 24px; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); border: 1px solid rgb(102, 102, 102); border-top-left-radius: 0px; border-top-right-radius: 0px; width: 205px; background-color: rgb(221, 221, 221);">
                                                                <label class="bar-item-text"> Document Center</label>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="linkArea" id="5eb5cef2-b70a-c985-c1b6-7de3055f697flinkArea" style="width: 0px; height: 0px;">
                                                        <div class="page-link" style="left: 216px; top: 0px; width: 205px; height: 24px;"></div>
                                                        <div class="page-link" style="left: 420px; top: 0px; width: 205px; height: 24px;"></div>
                                                        <div class="page-link" style="left: 624px; top: 0px; width: 205px; height: 24px;"></div>
                                                        <div class="page-link" style="left: 828px; top: 0px; width: 205px; height: 24px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 1;">
                                                <div id="fa876664-7303-1b51-a7c9-cb54987c619c" class="component component-TitleWindow" style="left: 53px; top: 120px; width: 932px; height: 257px; padding: 0px; opacity: 1; z-index: 1; transform: scaleX(1) scaleY(1);">
                                                    <div class="component" style="width: 932px; height: 257px; border: 2px solid rgb(255, 255, 0); box-sizing: border-box; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); background-color: rgb(255, 204, 0);">
                                                        <div class="title" style="height: 30px; line-height: 30px; z-index: 2; border-bottom-width: 1px; border-bottom-style: solid; border-color: rgb(255, 255, 0);">
                                                            <label style="height: 30px; line-height: 30px;"> Payments</label>
                                                            <div class="icon-box" style="height: auto; right: 6px; bottom: 3px;"></div>
                                                        </div>
                                                        <div class="content" style="top: 30px; height: 199px; z-index: 1; background-color: rgb(255, 204, 0);"></div>
                                                        <div class="status-bar" style="height: 24px; z-index: 3; border-top-width: 1px; border-top-style: solid; border-top-color: rgb(255, 255, 0);">
                                                            <div class="icon-box"></div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 2;">
                                                <div id="aa3fce2a-0452-16b7-4bc3-6908b5d5244f" class="component component-TitleWindow" style="left: 535px; top: 408px; width: 450px; height: 315px; padding: 0px; opacity: 1; z-index: 2; transform: scaleX(1) scaleY(1);">
                                                    <div class="component" style="width: 450px; height: 315px; border: 2px solid rgb(102, 102, 102); box-sizing: border-box; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); background-color: rgb(38, 198, 218);">
                                                        <div class="title" style="height: 30px; line-height: 30px; z-index: 2; border-bottom-width: 1px; border-bottom-style: solid; border-color: rgb(102, 102, 102);">
                                                            <label style="height: 30px; line-height: 30px;">Communications</label>
                                                            <div class="icon-box" style="height: auto; right: 6px; bottom: 3px;"></div>
                                                        </div>
                                                        <div class="content" style="top: 30px; height: 257px; z-index: 1; background-color: rgb(38, 198, 218);"></div>
                                                        <div class="status-bar" style="height: 24px; z-index: 3; border-top-width: 1px; border-top-style: solid; border-top-color: rgb(102, 102, 102);">
                                                            <div class="icon-box"></div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 3;">
                                                <div id="356eedf4-f0da-6be7-caf9-da0dfc237c00" class="component component-Label" style="left: 594px; top: 464px; width: 118px; height: 26px; padding: 0px; opacity: 1; z-index: 3; line-height: 25px; transform: scaleX(1) scaleY(1);">
                                                    <div class="context" style="position: absolute; line-height: 24px; background-color: rgba(0, 0, 0, 0);">
                                                        <div style="width: auto; height: auto; text-align: left;">
                                                            <div style="width: auto; height: auto;">
                                                                <label style="white-space: nowrap; text-align: left; font-size: 18px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0);">Email a Coach</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 4;">
                                                <div id="8dd4bc51-27c2-21e4-5079-cf403420b180" class="component component-CompositeComboBox" style="left: 726px; top: 458px; width: 200px; height: 36px; padding: 0px; opacity: 1; z-index: 4; transform: scaleX(1) scaleY(1);">
                                                    <div style="font-weight: bold; color: rgb(0, 0, 0); font-size: 20px; font-style: normal; text-decoration: none;">
                                                        <div style="position: absolute; width: 100%; height: 100%; box-sizing: border-box; border: 1px solid rgb(102, 102, 102); line-height: 36px; background-color: rgb(255, 255, 255);">
                                                            <div style="position: absolute; left: 0px; right: 24px; height: 100%; padding: 0px 5px; overflow: hidden;">
                                                                <label>Coach 1
                                                                </label>
                                                            </div>
                                                            <div style="position: absolute; height: 100%; width: 24px; top: 0px; right: 0px; border-left-width: 1px; border-left-style: solid; border-left-color: rgb(102, 102, 102);">
                                                                <div style="border-style: solid; border-width: 4px 4px 0px; border-color: black transparent transparent; width: 0px; height: 0px; position: absolute; left: 0px; right: 0px; top: 0px; bottom: 0px; margin: auto;"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 5;">
                                                <div id="6befc6e0-aa0f-00ba-fb3c-11c60437e92b" class="component component-CircleProgressBar" style="left: 132px; top: 159px; width: 111px; height: 111px; padding: 0px; opacity: 1; z-index: 5; transform: scaleX(1) scaleY(1);">
                                                    <div style="width: 100%; height: 100%; text-align: center; line-height: 111px; white-space: nowrap; font-size: 40px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0);">
                                                        <canvas width="111" height="111" style="left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;"></canvas>
                                                        <label>75%</label>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 6;">
                                                <div id="323ab775-e9c3-44af-3445-2cb1f56c2a6e" class="component component-Label" style="left: 84px; top: 306px; width: 196px; height: 29px; padding: 0px; opacity: 1; z-index: 6; line-height: 28px; transform: scaleX(1) scaleY(1);">
                                                    <div class="context" style="position: absolute; line-height: 27px; background-color: rgba(0, 0, 0, 0);">
                                                        <div style="width: auto; height: auto; text-align: left;">
                                                            <div style="width: auto; height: auto;">
                                                                <label style="white-space: nowrap; text-align: left; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(255, 0, 0);">Total % of Payments</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 7;">
                                                <div id="fef84ae5-1287-2102-73c6-868b3a9d2902" class="component component-Label" style="left: 406px; top: 306px; width: 178px; height: 29px; padding: 0px; opacity: 1; z-index: 7; line-height: 28px; transform: scaleX(1) scaleY(1);">
                                                    <div class="context" style="position: absolute; line-height: 27px; background-color: rgba(0, 0, 0, 0);">
                                                        <div style="width: auto; height: auto; text-align: left;">
                                                            <div style="width: auto; height: auto;">
                                                                <label style="white-space: nowrap; text-align: left; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(255, 0, 0);">Total Income 2019</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 8;">
                                                <div id="0785662b-e53b-085e-d335-a540b9235dc7" class="component component-__group__" style="left: 714px; top: 163px; width: 243px; height: 170px; padding: 0px; opacity: 1; z-index: 8; transform: scaleX(1) scaleY(1);">
                                                    <div class="component component-Group" style="cursor: default;">
                                                        <div style="position: absolute; z-index: 1;">
                                                            <div id="1ddcc986-9dc4-081a-4e91-7c246f6e90f4" class="component component-PieChartEx" style="left: 71px; top: 0px; width: 105px; height: 106px; padding: 0px; opacity: 1; z-index: 0; transform: scaleX(1) scaleY(1);">
                                                                <div class="component-SimpleCom">
                                                                    <canvas width="105" height="106">浏览器不支持canvas</canvas>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="f2ca224b-9ce8-6147-c894-f591d8401f28" class="component component-Label" style="left: 0px; top: 116px; width: 234px; height: 29px; padding: 0px; opacity: 1; z-index: 1; line-height: 28px; transform: scaleX(1) scaleY(1);">
                                                                <div class="context" style="position: absolute; line-height: 27px; background-color: rgba(0, 0, 0, 0);">
                                                                    <div style="width: auto; height: auto; text-align: left;">
                                                                        <div style="width: auto; height: auto;">
                                                                            <label style="white-space: nowrap; text-align: left; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0);">Green Paid &nbsp; Blue Pending</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="bbe7cb68-ab78-f798-fdad-be56316d037e" class="component component-Label" style="left: 3px; top: 143px; width: 240px; height: 29px; padding: 0px; opacity: 1; z-index: 2; line-height: 28px; transform: scaleX(1) scaleY(1);">
                                                                <div class="context" style="position: absolute; line-height: 27px; background-color: rgba(0, 0, 0, 0);">
                                                                    <div style="width: auto; height: auto; text-align: left;">
                                                                        <div style="width: auto; height: auto;">
                                                                            <label style="white-space: nowrap; text-align: left; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(255, 0, 0);">Paid vs, Pending Athletes</label>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 9;">
                                                <div id="a9744f51-da3b-93ed-2356-3c3cc329ce55" class="component component-TextArea" style="left: 553px; top: 550px; width: 373px; height: 101px; padding: 0px; opacity: 1; z-index: 9; transform: scaleX(1) scaleY(1);">
                                                    <div class="Border" style="padding: 0px; overflow: hidden; position: relative; box-sizing: border-box; left: 0px; top: 0px; width: 100%; height: 100%; border: 1px solid rgb(0, 0, 0); border-radius: 0px; z-index: 0; background-color: rgba(255, 255, 255, 0);">
                                                        <div style="font-size: 18px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); left: 0px; top: 0px; width: 373px; height: 100%; position: relative; word-wrap: break-word; word-break: break-word; box-sizing: border-box; z-index: 10; line-height: 25px;">
                                                            <div style="text-align: left; left: 0px; width: 373px; overflow: hidden; position: absolute; line-height: inherit; top: 0px;">
                                                                <p style="margin: 0px; padding: 0px; width: 373px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>&nbsp;&nbsp;Enter Message Here</span></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 10;">
                                                <div id="f45272c5-02c2-c8e6-dd3f-7fda5cf7adbc" class="component component-Label" style="left: 644px; top: 516px; width: 63px; height: 26px; padding: 0px; opacity: 1; z-index: 10; line-height: 25px; transform: scaleX(1) scaleY(1);">
                                                    <div class="context" style="position: absolute; line-height: 24px; background-color: rgba(0, 0, 0, 0);">
                                                        <div style="width: auto; height: auto; text-align: left;">
                                                            <div style="width: auto; height: auto;">
                                                                <label style="white-space: nowrap; text-align: left; font-size: 18px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0);">Subject</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 11;">
                                                <div id="ce7c6b5d-bb6c-7147-64e2-ab040d6d88fd" class="component component-TextInput" style="left: 726px; top: 509px; width: 200px; height: 35px; padding: 0px; opacity: 1; z-index: 11; transform: scaleX(1) scaleY(1);">
                                                    <div>
                                                        <input type="text" value="" placeholder="" style="position: absolute; z-index: 2; width: 200px; height: 35px; border: 1px solid rgb(102, 102, 102); padding-left: 2px; padding-right: 2px; margin: 0px; box-sizing: border-box; outline: none; line-height: 33px; text-align: left; font-size: 18px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); border-radius: 0px; background-color: rgb(255, 255, 255);">
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 12;">
                                                <div id="bfd16b7a-e4d1-e12e-039b-ac53555a21ea" class="component component-Button" style="left: 856px; top: 661px; width: 70px; height: 28px; padding: 0px; opacity: 1; z-index: 12; transform: scaleX(1) scaleY(1);">
                                                    <diy class="component component-button" style="border-radius: 4px; border: 1px solid rgb(102, 102, 102); box-sizing: border-box; font-size: 18px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); text-align: center; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute; overflow: hidden; z-index: 12; line-height: 25px; white-space: pre-wrap; word-wrap: break-word; background-color: rgb(255, 255, 255);">
                                                        <div style="left: 1px; right: 1px; top: 1.3px; height: auto; position: absolute; line-height: 23.94px;">
                                                            <p style="font-size: 18px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); padding: 0px; margin: 0px; word-break: break-word;">Send</p>
                                                        </div>
                                                    </diy>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 13;">
                                                <div id="ee720967-49a0-fe59-4664-1d576645e6df" class="component component-__group__" style="left: 53px; top: 408px; width: 453px; height: 315px; padding: 0px; opacity: 1; z-index: 13; transform: scaleX(1) scaleY(1);">
                                                    <div class="component component-Group" style="cursor: default;">
                                                        <div style="position: absolute; z-index: 1;">
                                                            <div id="afc8fddb-d191-5833-61d3-ef2b778a51f4" class="component component-TitleWindow" style="left: 0px; top: 0px; width: 453px; height: 315px; padding: 0px; opacity: 1; z-index: 0; transform: scaleX(1) scaleY(1);">
                                                                <div class="component" style="width: 453px; height: 315px; border: 2px solid rgb(102, 102, 102); box-sizing: border-box; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); background-color: rgb(0, 153, 51);">
                                                                    <div class="title" style="height: 30px; line-height: 30px; z-index: 2; border-bottom-width: 1px; border-bottom-style: solid; border-color: rgb(102, 102, 102);">
                                                                        <label style="height: 30px; line-height: 30px;">Coaches</label>
                                                                        <div class="icon-box" style="height: auto; right: 6px; bottom: 3px;"></div>
                                                                    </div>
                                                                    <div class="content" style="top: 30px; height: 257px; z-index: 1; background-color: rgb(0, 153, 51);"></div>
                                                                    <div class="status-bar" style="height: 24px; z-index: 3; border-top-width: 1px; border-top-style: solid; border-top-color: rgb(102, 102, 102);">
                                                                        <div class="icon-box"></div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="f4be259c-287c-1196-42f3-59076ad165ef" class="component component-TextArea" style="left: 7px; top: 50px; width: 241px; height: 217px; padding: 0px; opacity: 1; z-index: 1; transform: scaleX(1) scaleY(1);">
                                                                <div class="Border" style="padding: 0px; overflow: hidden; position: relative; box-sizing: border-box; left: 0px; top: 0px; width: 100%; height: 100%; border: 1px none rgb(102, 102, 102); border-radius: 0px; z-index: 0; background-color: rgba(255, 255, 255, 0);">
                                                                    <div style="font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(255, 255, 255); left: 0px; top: 0px; width: 241px; height: 100%; position: relative; word-wrap: break-word; word-break: break-word; box-sizing: border-box; z-index: 10; line-height: 28px;">
                                                                        <div style="text-align: right; left: 0px; width: 241px; overflow: hidden; position: absolute; line-height: inherit; top: 0px;">
                                                                            <p style="margin: 0px; padding: 0px; width: 241px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: right; text-decoration: none;"><span>Background Check Done:
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 241px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: right; text-decoration: none;"><span>Forms Received:
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 241px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: right; text-decoration: none;"><span>Payment Received: &nbsp; &nbsp; </span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="631f7d1c-236c-9a79-c320-69f83442efb1" class="component component-TextArea" style="left: 261px; top: 49px; width: 112px; height: 202px; padding: 0px; opacity: 1; z-index: 2; transform: scaleX(1) scaleY(1);">
                                                                <div class="Border" style="padding: 0px; overflow: hidden; position: relative; box-sizing: border-box; left: 0px; top: 0px; width: 100%; height: 100%; border: 1px none rgb(102, 102, 102); border-radius: 0px; z-index: 0; background-color: rgba(255, 255, 255, 0);">
                                                                    <div style="font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(255, 255, 255); left: 0px; top: 0px; width: 112px; height: 100%; position: relative; word-wrap: break-word; word-break: break-word; box-sizing: border-box; z-index: 10; line-height: 28px;">
                                                                        <div style="text-align: left; left: 0px; width: 112px; overflow: hidden; position: absolute; line-height: inherit; top: 0px;">
                                                                            <p style="margin: 0px; padding: 0px; width: 112px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>32
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 112px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>22
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 112px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>22</span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 14;">
                                                <div id="a9b3bc36-d88a-ae6d-69de-e2420fdd6389" class="component component-__group__" style="left: 53px; top: 748px; width: 450px; height: 315px; padding: 0px; opacity: 1; z-index: 14; transform: scaleX(1) scaleY(1);">
                                                    <div class="component component-Group" style="cursor: default;">
                                                        <div style="position: absolute; z-index: 1;">
                                                            <div id="dae4d1ae-3b45-bb27-e131-fceb3532f2d3" class="component component-TitleWindow" style="left: 0px; top: 0px; width: 450px; height: 315px; padding: 0px; opacity: 1; z-index: 0; transform: scaleX(1) scaleY(1);">
                                                                <div class="component" style="width: 450px; height: 315px; border: 2px solid rgb(102, 102, 102); box-sizing: border-box; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); background-color: rgb(255, 0, 0);">
                                                                    <div class="title" style="height: 30px; line-height: 30px; z-index: 2; border-bottom-width: 1px; border-bottom-style: solid; border-color: rgb(102, 102, 102);">
                                                                        <label style="height: 30px; line-height: 30px;">Athletes</label>
                                                                        <div class="icon-box" style="height: auto; right: 6px; bottom: 3px;"></div>
                                                                    </div>
                                                                    <div class="content" style="top: 30px; height: 257px; z-index: 1; background-color: rgb(255, 0, 0);"></div>
                                                                    <div class="status-bar" style="height: 24px; z-index: 3; border-top-width: 1px; border-top-style: solid; border-top-color: rgb(102, 102, 102);">
                                                                        <div class="icon-box"></div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="a8103a7d-37e1-31c2-d804-085bcce698e7" class="component component-TextArea" style="left: 19px; top: 39px; width: 240px; height: 242px; padding: 0px; opacity: 1; z-index: 1; transform: scaleX(1) scaleY(1);">
                                                                <div class="Border" style="padding: 0px; overflow: hidden; position: relative; box-sizing: border-box; left: 0px; top: 0px; width: 100%; height: 100%; border: 1px none rgb(102, 102, 102); border-radius: 0px; z-index: 0; background-color: rgba(255, 255, 255, 0);">
                                                                    <div style="font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); left: 0px; top: 0px; width: 240px; height: 100%; position: relative; word-wrap: break-word; word-break: break-word; box-sizing: border-box; z-index: 10; line-height: 28px;">
                                                                        <div style="text-align: right; left: 0px; width: 240px; overflow: hidden; position: absolute; line-height: inherit; top: 0px;">
                                                                            <p style="margin: 0px; padding: 0px; width: 240px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: right; text-decoration: none;"><span>Forms Received:
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 240px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: right; text-decoration: none;"><span>Payment Received:
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 240px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: right; text-decoration: none;"><span>Male:
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 240px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: right; text-decoration: none;"><span>Female:
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 240px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: right; text-decoration: none;"><span>M:F Ratio: &nbsp; &nbsp; </span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="781c7427-67bd-f41d-34fc-079fa7ecca1b" class="component component-TextArea" style="left: 280px; top: 42px; width: 147px; height: 247px; padding: 0px; opacity: 1; z-index: 2; transform: scaleX(1) scaleY(1);">
                                                                <div class="Border" style="padding: 0px; overflow: hidden; position: relative; box-sizing: border-box; left: 0px; top: 0px; width: 100%; height: 100%; border: 1px none rgb(102, 102, 102); border-radius: 0px; z-index: 0; background-color: rgba(255, 255, 255, 0);">
                                                                    <div style="font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); left: 0px; top: 0px; width: 147px; height: 100%; position: relative; word-wrap: break-word; word-break: break-word; box-sizing: border-box; z-index: 10; line-height: 28px;">
                                                                        <div style="text-align: left; left: 0px; width: 147px; overflow: hidden; position: absolute; line-height: inherit; top: 0px;">
                                                                            <p style="margin: 0px; padding: 0px; width: 147px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>10232
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 147px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>2322
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 147px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>1545
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 147px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>812
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 147px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>3:1</span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 15;">
                                                <div id="61fe81e3-7152-35af-e349-db6663b33458" class="component component-__group__" style="left: 535px; top: 748px; width: 450px; height: 315px; padding: 0px; opacity: 1; z-index: 15; transform: scaleX(1) scaleY(1);">
                                                    <div class="component component-Group" style="cursor: default;">
                                                        <div style="position: absolute; z-index: 1;">
                                                            <div id="3cc57181-a571-5ffb-b39a-df6ec8339bb3" class="component component-TitleWindow" style="left: 0px; top: 0px; width: 450px; height: 315px; padding: 0px; opacity: 1; z-index: 0; transform: scaleX(1) scaleY(1);">
                                                                <div class="component" style="width: 450px; height: 315px; border: 2px solid rgb(102, 102, 102); box-sizing: border-box; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); background-color: rgb(255, 190, 107);">
                                                                    <div class="title" style="height: 30px; line-height: 30px; z-index: 2; border-bottom-width: 1px; border-bottom-style: solid; border-color: rgb(102, 102, 102);">
                                                                        <label style="height: 30px; line-height: 30px;">Reports</label>
                                                                        <div class="icon-box" style="height: auto; right: 6px; bottom: 3px;"></div>
                                                                    </div>
                                                                    <div class="content" style="top: 30px; height: 257px; z-index: 1; background-color: rgb(255, 190, 107);"></div>
                                                                    <div class="status-bar" style="height: 24px; z-index: 3; border-top-width: 1px; border-top-style: solid; border-top-color: rgb(102, 102, 102);">
                                                                        <div class="icon-box"></div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="e571348b-b67e-bb55-6a30-a90e5ea053b0" class="component component-TextArea" style="left: 84px; top: 47px; width: 325px; height: 217px; padding: 0px; opacity: 1; z-index: 1; transform: scaleX(1) scaleY(1);">
                                                                <div class="Border" style="padding: 0px; overflow: hidden; position: relative; box-sizing: border-box; left: 0px; top: 0px; width: 100%; height: 100%; border: 1px none rgb(102, 102, 102); border-radius: 0px; z-index: 0; background-color: rgba(255, 255, 255, 0);">
                                                                    <div style="font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); left: 0px; top: 0px; width: 325px; height: 100%; position: relative; word-wrap: break-word; word-break: break-word; box-sizing: border-box; z-index: 10; line-height: 28px;">
                                                                        <div style="text-align: left; left: 0px; width: 325px; overflow: hidden; position: absolute; line-height: inherit; top: 0px;">
                                                                            <p style="margin: 0px; padding: 0px; width: 325px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>Payment by Teams
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 325px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>Athletes with Missing Paperwork
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 325px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>Regional Athlete Status
</span></p>
                                                                            <br>
                                                                            <p style="margin: 0px; padding: 0px; width: 325px; transform: scale(1); transform-origin: left top 0px; text-overflow: clip; white-space: normal; text-align: left; text-decoration: none;"><span>Upcoming Events &nbsp; &nbsp; </span></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="b14f443e-c44e-4731-389e-b98d481904b0" class="component component-Icon" style="left: 47px; top: 51px; width: 24px; height: 24px; padding: 0px; opacity: 1; z-index: 2; transform: scaleX(1) scaleY(1);">
                                                                <div style="width: 24px; height: 24px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                    <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdFontAwesome; font-size: 24px; color: rgb(0, 0, 0); text-align: center; line-height: 24px; background-color: rgba(0, 0, 0, 0);"></div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="d9f3122f-2ace-648f-1e7e-359548b90719" class="component component-Icon" style="left: 47px; top: 104px; width: 24px; height: 24px; padding: 0px; opacity: 1; z-index: 3; transform: scaleX(1) scaleY(1);">
                                                                <div style="width: 24px; height: 24px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                    <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdFontAwesome; font-size: 24px; color: rgb(0, 0, 0); text-align: center; line-height: 24px; background-color: rgba(0, 0, 0, 0);"></div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="1566078c-54fc-a2c7-7ffd-71c22b0a68d9" class="component component-Icon" style="left: 47px; top: 157px; width: 24px; height: 24px; padding: 0px; opacity: 1; z-index: 4; transform: scaleX(1) scaleY(1);">
                                                                <div style="width: 24px; height: 24px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                    <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdFontAwesome; font-size: 24px; color: rgb(0, 0, 0); text-align: center; line-height: 24px; background-color: rgba(0, 0, 0, 0);"></div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                            <div id="37d35abf-b9e9-3b8d-8b99-89ebe3675e0d" class="component component-Icon" style="left: 47px; top: 211px; width: 24px; height: 24px; padding: 0px; opacity: 1; z-index: 5; transform: scaleX(1) scaleY(1);">
                                                                <div style="width: 24px; height: 24px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                    <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdFontAwesome; font-size: 24px; color: rgb(0, 0, 0); text-align: center; line-height: 24px; background-color: rgba(0, 0, 0, 0);"></div>
                                                                </div>
                                                                <div style="display: none;"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 16;">
                                                <div id="69b9cd7c-119c-b81f-62d2-886172dfe92e" class="component component-Icon" style="left: 387px; top: 214px; width: 50px; height: 50px; padding: 0px; opacity: 1; z-index: 16; transform: scaleX(1) scaleY(1);">
                                                    <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                        <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIonicons; font-size: 50px; color: rgb(0, 0, 0); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 17;">
                                                <div id="03c4f4f5-760f-59d9-37da-ce8999f75029" class="component component-Label" style="left: 482px; top: 155px; width: 68px; height: 46px; padding: 0px; opacity: 1; z-index: 17; line-height: 45px; transform: scaleX(1) scaleY(1);">
                                                    <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                        <div style="width: auto; height: auto; text-align: left;">
                                                            <div style="width: auto; height: auto;">
                                                                <label style="white-space: nowrap; text-align: left; font-size: 32px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0);">TWF</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 18;">
                                                <div id="aea16548-b6d2-5bfc-cbd9-817d5dadbb2f" class="component component-Label" style="left: 436px; top: 194px; width: 191px; height: 82px; padding: 0px; opacity: 1; z-index: 18; line-height: 81px; transform: scaleX(1) scaleY(1);">
                                                    <div class="context" style="position: absolute; line-height: 80px; background-color: rgba(0, 0, 0, 0);">
                                                        <div style="width: auto; height: auto; text-align: left;">
                                                            <div style="width: auto; height: auto;">
                                                                <label style="white-space: nowrap; text-align: left; font-size: 60px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0);">93,750</label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 19;">
                                                <div id="bd063b3b-1b8e-3c7d-55b0-c082f225ef22" class="component component-TitleWindow" style="left: 53px; top: 1108px; width: 932px; height: 354px; padding: 0px; opacity: 1; z-index: 19; transform: scaleX(1) scaleY(1);">
                                                    <div class="component" style="width: 932px; height: 354px; border: 2px solid rgb(102, 102, 102); box-sizing: border-box; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0); background-color: rgb(255, 255, 255);">
                                                        <div class="title" style="height: 30px; line-height: 30px; z-index: 2; border-bottom-width: 1px; border-bottom-style: solid; border-color: rgb(102, 102, 102);">
                                                            <label style="height: 30px; line-height: 30px;">Active Tasks</label>
                                                            <div class="icon-box" style="height: auto; right: 6px; bottom: 3px;"></div>
                                                        </div>
                                                        <div class="content" style="top: 30px; height: 296px; z-index: 1; background-color: rgb(255, 255, 255);"></div>
                                                        <div class="status-bar" style="height: 24px; z-index: 3; border-top-width: 1px; border-top-style: solid; border-top-color: rgb(102, 102, 102);">
                                                            <div class="icon-box"></div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 20;">
                                                <div id="8bdf00bb-1f0d-3e43-bd32-8e1430854a5a" class="component component-IconLabel2" style="left: 94px; top: 1331px; width: 101px; height: 97px; padding: 0px; opacity: 1; z-index: 20; transform: scaleX(1) scaleY(1);">
                                                    <div class="contents-layout">
                                                        <div style="left: 26px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                                            <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdFontAwesome; font-size: 50px; color: rgb(51, 51, 255); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                                            </div>
                                                        </div>
                                                        <div style="left: 2px; top: 54px; width: 96px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                                            <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                                <div style="width: auto; height: auto; text-align: center;">
                                                                    <div style="width: auto; height: auto;">
                                                                        <label style="white-space: nowrap; text-align: center; font-size: 32px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(51, 51, 255);">Events</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="linkArea" id="8bdf00bb-1f0d-3e43-bd32-8e1430854a5alinkArea" style="width: 0px; height: 0px;">
                                                        <div class="page-link" style="left: 0px; top: 0px; width: 101px; height: 97px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 21;">
                                                <div id="8f659c52-9e41-f9d8-3378-b2ee6f13a5ac" class="component component-IconLabel2" style="left: 247px; top: 1186px; width: 174px; height: 97px; padding: 0px; opacity: 1; z-index: 21; transform: scaleX(1) scaleY(1);">
                                                    <div class="contents-layout">
                                                        <div style="left: 62px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                                            <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIcoMoonFree; font-size: 50px; color: rgb(153, 0, 51); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                                            </div>
                                                        </div>
                                                        <div style="left: 2px; top: 54px; width: 169px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                                            <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                                <div style="width: auto; height: auto; text-align: center;">
                                                                    <div style="width: auto; height: auto;">
                                                                        <label style="white-space: nowrap; text-align: center; font-size: 32px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(153, 0, 0);">Documents</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="linkArea" id="8f659c52-9e41-f9d8-3378-b2ee6f13a5aclinkArea" style="width: 0px; height: 0px;">
                                                        <div class="page-link" style="left: 0px; top: 0px; width: 174px; height: 97px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 22;">
                                                <div id="12427395-0ea2-ead5-8d5a-e0a7614bdcf3" class="component component-IconLabel2" style="left: 463px; top: 1186px; width: 123px; height: 97px; padding: 0px; opacity: 1; z-index: 22; transform: scaleX(1) scaleY(1);">
                                                    <div class="contents-layout">
                                                        <div style="left: 36px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                                            <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIcoFont; font-size: 50px; color: rgb(176, 126, 49); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                                            </div>
                                                        </div>
                                                        <div style="left: 2px; top: 54px; width: 120px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                                            <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                                <div style="width: auto; height: auto; text-align: center;">
                                                                    <div style="width: auto; height: auto;">
                                                                        <label style="white-space: nowrap; text-align: center; font-size: 32px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(176, 126, 49);">Regions</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 23;">
                                                <div id="110c2fc8-f376-135b-3a19-c5f58497ca3c" class="component component-IconLabel2" style="left: 628px; top: 1186px; width: 100px; height: 97px; padding: 0px; opacity: 1; z-index: 23; transform: scaleX(1) scaleY(1);">
                                                    <div class="contents-layout">
                                                        <div style="left: 25px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                                            <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIcoMoonFree; font-size: 50px; color: rgb(0, 102, 0); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                                            </div>
                                                        </div>
                                                        <div style="left: 2px; top: 54px; width: 96px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                                            <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                                <div style="width: auto; height: auto; text-align: center;">
                                                                    <div style="width: auto; height: auto;">
                                                                        <label style="white-space: nowrap; text-align: center; font-size: 32px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 102, 0);">Teams</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="linkArea" id="110c2fc8-f376-135b-3a19-c5f58497ca3clinkArea" style="width: 0px; height: 0px;">
                                                        <div class="page-link" style="left: 0px; top: 0px; width: 100px; height: 97px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div style="z-index: 24;">
                                                <div id="61c2d10d-f9ab-ebff-6ca7-1ab366f3bdf0" class="component component-IconLabel2" style="left: 770px; top: 1186px; width: 137px; height: 97px; padding: 0px; opacity: 1; z-index: 24; transform: scaleX(1) scaleY(1);">
                                                    <div class="contents-layout">
                                                        <div style="left: 44px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                                            <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIonicons; font-size: 50px; color: rgb(255, 0, 0); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                                            </div>
                                                        </div>
                                                        <div style="left: 2px; top: 54px; width: 132px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                                            <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                                <div style="width: auto; height: auto; text-align: center;">
                                                                    <div style="width: auto; height: auto;">
                                                                        <label style="white-space: nowrap; text-align: center; font-size: 32px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(255, 0, 0);">Statistics</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div style="display: none;"></div>
                                                </div>
                                            </div>
                                            <div style="z-index: 25;">
                                                <div id="44a84467-11be-ed43-4e50-31ec1147e9c3" class="component component-IconLabel2" style="left: 94px; top: 1186px; width: 116px; height: 97px; padding: 0px; opacity: 1; z-index: 25; transform: scaleX(1) scaleY(1);">
                                                    <div class="contents-layout">
                                                        <div style="left: 33px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                                            <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                                <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdFontAwesome; font-size: 50px; color: rgb(38, 198, 218); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                                            </div>
                                                        </div>
                                                        <div style="left: 2px; top: 54px; width: 112px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                                            <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                                <div style="width: auto; height: auto; text-align: center;">
                                                                    <div style="width: auto; height: auto;">
                                                                        <label style="white-space: nowrap; text-align: center; font-size: 32px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(38, 198, 218);">Notices</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="linkArea" id="44a84467-11be-ed43-4e50-31ec1147e9c3linkArea" style="width: 0px; height: 0px;">
                                                        <div class="page-link" style="left: 0px; top: 0px; width: 116px; height: 97px;"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="track scroll-bar-horizontal">
                                    <div class="thumb" style="width: 100%; left: 0%; display: none; opacity: 0;"></div>
                                </div>
                                <div class="track scroll-bar-vertical">
                                    <div class="thumb" style="height: 100%; top: 0%; display: none; opacity: 0;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <div class="comments" style="left: 0px; top: 0px; display: block;">
            <div id="comments-scroller" style="position: relative; top: 0px;"></div>
        </div>
    </div>



<?php

?>