<?php

?>


     <div class="components">
            <div >



                <div  class="component component-TitleWindow" style=" width: 100%; height: 354px; padding: 0px; opacity: 1;  transform: scaleX(1) scaleY(1);">
                     <div class="component" style="width: 100%; height: 354px; box-sizing: border-box; font-size: 20px; font-weight: 700; font-style: normal; text-decoration: none; font-family: 'Segoe UI'; color: rgb(0, 0, 0);">
                         <div class="title" style="height: 30px; line-height: 30px; z-index: 2;">
                             <label style="height: 30px; line-height: 30px;">Quick Links</label>
                             <div class="icon-box" style="height: auto; right: 6px; bottom: 3px;"></div>
                         </div>
                         <div class="content" style="top: 30px; height: 296px; z-index: 1; background-color: rgb(255, 255, 255);">
                             <div >
                                 <div  class="component component-IconLabel2" style=" width: 101px; height: 97px; padding: 0px; opacity: 1;  transform: scaleX(1) scaleY(1);">
                                     <div class="contents-layout">
                                         <div style="left: 26px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                             <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                 <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdFontAwesome; font-size: 50px; color: rgb(51, 51, 255); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                             </div>
                                         </div>
                                         <div style="left: 2px; top: 54px; width: 96px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                             <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                 <div style="width: auto; height: auto; text-align: center;">
                                                     <div style="width: auto; height: auto;">
                                                         <label class="lab_class" style=" color: rgb(51, 51, 255);">Events</label>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="linkArea"  style="width: 0px; height: 0px;">
                                         <div class="page-link" style="left: 0px; top: 0px; width: 101px; height: 97px;"></div>
                                     </div>
                                 </div>
                             </div>


                             <div >
                                 <div  class="component component-IconLabel2" style=" width: 174px; height: 97px; padding: 0px; opacity: 1;  transform: scaleX(1) scaleY(1);">
                                     <div class="contents-layout">
                                         <div style="left: 62px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                             <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                 <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIcoMoonFree; font-size: 50px; color: rgb(153, 0, 51); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                             </div>
                                         </div>
                                         <div style="left: 2px; top: 54px; width: 169px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                             <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                 <div style="width: auto; height: auto; text-align: center;">
                                                     <div style="width: auto; height: auto;">
                                                         <label class="lab_class" style=" color: rgb(153, 0, 0);">Documents</label>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="linkArea"  style="width: 0px; height: 0px;">
                                         <div class="page-link" style="left: 0px; top: 0px; width: 174px; height: 97px;"></div>
                                     </div>
                                 </div>
                             </div>

                             <div >
                                 <div  class="component component-IconLabel2" style=" width: 123px; height: 97px; padding: 0px; opacity: 1;  transform: scaleX(1) scaleY(1);">
                                     <div class="contents-layout">
                                         <div style="left: 36px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                             <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                 <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIcoFont; font-size: 50px; color: rgb(176, 126, 49); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                             </div>
                                         </div>
                                         <div style="left: 2px; top: 54px; width: 120px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                             <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                 <div style="width: auto; height: auto; text-align: center;">
                                                     <div style="width: auto; height: auto;">
                                                         <label class="lab_class" style=" color: rgb(176, 126, 49);">Regions</label>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div style="display: none;"></div>
                                 </div>
                             </div>
                             <div>
                                 <div  class="component component-IconLabel2" style=" width: 100px; height: 97px; padding: 0px; opacity: 1;  transform: scaleX(1) scaleY(1);">
                                     <div class="contents-layout">
                                         <div style="left: 25px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                             <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                 <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIcoMoonFree; font-size: 50px; color: rgb(0, 102, 0); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                             </div>
                                         </div>
                                         <div style="left: 2px; top: 54px; width: 96px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                             <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                 <div style="width: auto; height: auto; text-align: center;">
                                                     <div style="width: auto; height: auto;">
                                                         <label class="lab_class" style=" color: rgb(0, 102, 0);">Teams</label>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="linkArea"  style="width: 0px; height: 0px;">
                                         <div class="page-link" style="left: 0px; top: 0px; width: 100px; height: 97px;"></div>
                                     </div>
                                 </div>
                             </div>
                             <div >
                                 <div  class="component component-IconLabel2" style=" width: 137px; height: 97px; padding: 0px; opacity: 1;  transform: scaleX(1) scaleY(1);">
                                     <div class="contents-layout">
                                         <div style="left: 44px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                             <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                 <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdIonicons; font-size: 50px; color: rgb(255, 0, 0); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                             </div>
                                         </div>
                                         <div style="left: 2px; top: 54px; width: 132px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                             <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                 <div style="width: auto; height: auto; text-align: center;">
                                                     <div style="width: auto; height: auto;">
                                                         <label class="lab_class" style=" color: rgb(255, 0, 0);">Statistics</label>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div style="display: none;"></div>
                                 </div>
                             </div>
                             <div >
                                 <div  class="component component-IconLabel2" style=" width: 116px; height: 97px; padding: 0px; opacity: 1;  transform: scaleX(1) scaleY(1);">
                                     <div class="contents-layout">
                                         <div style="left: 33px; top: 0px; width: 50px; height: 50px; position: absolute; border: none; pointer-events: none; z-index: 1; white-space: nowrap;">
                                             <div style="width: 50px; height: 50px; left: 0px; top: 0px; border: none; position: absolute;">
                                                 <div class="" style="border-style: none; width: 100%; height: 100%; pointer-events: none; position: absolute; font-family: jdFontAwesome; font-size: 50px; color: rgb(38, 198, 218); text-align: center; line-height: 50px; background-color: rgba(0, 0, 0, 0);"></div>
                                             </div>
                                         </div>
                                         <div style="left: 2px; top: 54px; width: 112px; height: 46px; position: absolute; border: none; pointer-events: none; z-index: 2; white-space: nowrap; line-height: 45px;">
                                             <div class="context" style="position: absolute; line-height: 43px; background-color: rgba(0, 0, 0, 0);">
                                                 <div style="width: auto; height: auto; text-align: center;">
                                                     <div style="width: auto; height: auto;">
                                                         <label class="lab_class" style=" color: rgb(38, 198, 218);">Notices</label>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>
                                     <div class="linkArea"  style="width: 0px; height: 0px;">
                                         <div class="page-link" style="left: 0px; top: 0px; width: 116px; height: 97px;"></div>
                                     </div>
                                 </div>
                             </div>


                         </div>
                         
                     </div>




                 </div>
             </div>

    </div>





<?php

?>