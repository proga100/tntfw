<?php
function my_theme_enqueue_styles() {

    $parent_style = 'parent-style'; // This is 'twentyfifteen-style' for the Twenty Fifteen theme.

    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get('Version')
    );
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );

function eo_get_usermeta($meta_key)
{
    $current_user = wp_get_current_user();
    $ret = (($current_user instanceof WP_User) && (0 != $current_user->ID)) ?
        $current_user->__get($meta_key) : '';

    return $ret;
}


add_filter('gform_field_value_first_name', 'eo_populate_name');
add_filter('gform_field_value_last_name',  'eo_populate_name');



function eo_populate_name($value)
{



    // extract the parameter name from the current filter name
    $param = str_replace('gform_field_value_', '', current_filter());

    // we are interested only in the first_name and last_name parameters
    if ( !in_array($param, array('first_name', 'last_name')) )
        return $value;

    // incidentally, the user meta keys for the first and last name are
    // 'first_name' and 'last_name', the same as the parameter names
    $value = eo_get_usermeta($param);

    return $value;
}

