<?php

?>

     <div class="components coaches_report">
			<div class="fl_left">
              <div  class=" boxes boxes_light_blue" >


                        <div  class="boxes_title" >

                            <div class="title title_1" >
                                <label style="height: 30px; line-height: 30px;">Reports</label>
                                 
                                 </div>
                        </div>
                         <div class="box_text" >
                             
                    <div class="box_text_left box_report">
                        <div style="width: 24px; height: 24px;  border: none; position:">
                         
                         </div>
                    </div>  <div class="box_text_rigth box_text_rigth_report"> Payment by Teams</div>
                            <div class="clear"></div>
                              <div class="box_text_left box_report">
                                  <div style="width: 24px; height: 24px;  border: none; position:">
                                     
                                  </div>
                              </div>  <div class="box_text_rigth box_text_rigth_report">Athletes with Missing Paperwork</div>
                              <div class="clear"></div>
                              <div class="box_text_left box_report">
                                  <div style="width: 24px; height: 24px;  border: none; position:">
                                      
                                  </div>
                              </div>  <div class="box_text_rigth box_text_rigth_report"> Regional Athlete Status</div>
                              <div class="clear"></div>
                               <div class="box_text_left box_report">
                                   <div style="width: 24px; height: 24px;  border: none; position:">
                                      
                                   </div>
                               </div>
                             <div class="box_text_rigth box_text_rigth_report"> Upcoming Events  </div>
                               <div class="clear"></div>

                         </div>
                          <div  class="boxes_title  " >

                                 <div class="title title_1 boxes_title_bottom" >
                                     <label style="height: 30px; line-height: 30px;"></label>

                                 </div>
                             </div>

                        </div>
             </div>

    </div>



<?php

?>